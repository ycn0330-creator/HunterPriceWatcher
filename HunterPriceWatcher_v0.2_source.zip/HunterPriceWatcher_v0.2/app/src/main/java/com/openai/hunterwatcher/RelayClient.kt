package com.openai.hunterwatcher

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

object RelayClient {
    private const val BASE = "https://ntfy.sh"
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun publishAlert(context: Context, rates: RateTriple, force: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        if (!force && Prefs.isQuietTime()) {
            LogStore.add(context, "야간 시간대: 원격 알림 생략")
            return@withContext false
        }
        if (!force && rates.max() < Prefs.THRESHOLD) return@withContext false

        val now = ZonedDateTime.now(Prefs.SEOUL_ZONE).format(DateTimeFormatter.ofPattern("HH:mm"))
        val bodyText = "$now · 금 x${rates.gold.oneDecimal()} / 은 x${rates.silver.oneDecimal()} / 구리 x${rates.copper.oneDecimal()}"
        val req = Request.Builder()
            .url("$BASE/${Uri.encode(Prefs.topic(context))}")
            .addHeader("Title", "헌터 퀘스트 x5.8+ 시세")
            .addHeader("Priority", "high")
            .post(bodyText.toRequestBody("text/plain; charset=utf-8".toMediaType()))
            .build()
        return@withContext try {
            client.newCall(req).execute().use { res ->
                if (res.isSuccessful) {
                    LogStore.add(context, "원격 알림 전송: $bodyText")
                    true
                } else {
                    LogStore.add(context, "원격 알림 전송 실패 HTTP ${res.code}")
                    false
                }
            }
        } catch (t: Throwable) {
            LogStore.add(context, "원격 알림 전송 오류: ${t.message}")
            false
        }
    }

    suspend fun pollAndNotify(context: Context) = withContext(Dispatchers.IO) {
        if (Prefs.isQuietTime()) return@withContext
        val lastId = Prefs.lastNtfyId(context)
        val since = if (lastId.isNullOrBlank()) "10m" else lastId
        val url = "$BASE/${Uri.encode(Prefs.topic(context))}/json?poll=1&since=${Uri.encode(since)}"
        val req = Request.Builder().url(url).get().build()
        try {
            client.newCall(req).execute().use { res ->
                if (!res.isSuccessful) {
                    LogStore.add(context, "원격 수신 실패 HTTP ${res.code}")
                    return@use
                }
                val text = res.body?.string().orEmpty()
                var newestId: String? = lastId
                text.lineSequence().filter { it.isNotBlank() }.forEach { line ->
                    val json = runCatching { JSONObject(line) }.getOrNull() ?: return@forEach
                    if (json.optString("event") != "message") return@forEach
                    val id = json.optString("id")
                    val epoch = json.optLong("time", 0)
                    if (id.isNotBlank() && id == lastId) return@forEach
                    if (id.isNotBlank()) newestId = id
                    val ageSeconds = if (epoch > 0) Instant.now().epochSecond - epoch else 0
                    if (ageSeconds !in 0..600) return@forEach
                    val title = json.optString("title", "헌터 퀘스트 고시세")
                    val message = json.optString("message")
                    if (message.isNotBlank()) {
                        NotificationHelper.show(context, title, message)
                        LogStore.add(context, "S26 알림 표시: $message")
                    }
                }
                newestId?.takeIf { it.isNotBlank() }?.let { Prefs.setLastNtfyId(context, it) }
            }
        } catch (t: Throwable) {
            LogStore.add(context, "원격 수신 오류: ${t.message}")
        }
    }

    private fun Double.oneDecimal() = String.format(java.util.Locale.US, "%.1f", this)
}

data class RateTriple(val gold: Double, val silver: Double, val copper: Double) {
    fun max(): Double = maxOf(gold, silver, copper)
    fun closeTo(other: RateTriple, eps: Double = 0.05): Boolean =
        kotlin.math.abs(gold - other.gold) <= eps &&
        kotlin.math.abs(silver - other.silver) <= eps &&
        kotlin.math.abs(copper - other.copper) <= eps
}
