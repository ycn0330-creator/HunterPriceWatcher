package com.openai.hunterwatcher

import android.Manifest
import android.app.AlarmManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.openai.hunterwatcher.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        load()
        requestNotificationIfNeeded()

        binding.newCodeButton.setOnClickListener {
            binding.topicEdit.setText(Prefs.newTopicCode())
        }
        binding.copyCodeButton.setOnClickListener {
            val cm = getSystemService(ClipboardManager::class.java)
            cm.setPrimaryClip(ClipData.newPlainText("헌터 시세 연동 코드", binding.topicEdit.text.toString()))
            toast("연동 코드를 복사했습니다")
        }
        binding.saveButton.setOnClickListener {
            save()
            Scheduler.scheduleNext(this)
            toast("저장했습니다")
            refreshLog()
        }
        binding.accessibilityButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        binding.exactAlarmButton.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 31) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            } else toast("이 Android 버전은 별도 권한이 필요 없습니다")
        }
        binding.manualButton.setOnClickListener {
            save()
            if (Prefs.role(this) == Prefs.ROLE_COLLECTOR) {
                if (!HunterAccessibilityService.requestAutomation("수동")) toast("접근성 서비스를 먼저 켜주세요")
            } else {
                scope.launch(Dispatchers.IO) {
                    RelayClient.pollAndNotify(this@MainActivity)
                    runOnUiThread { refreshLog() }
                }
            }
        }
        binding.testAlertButton.setOnClickListener {
            save()
            scope.launch(Dispatchers.IO) {
                RelayClient.publishAlert(this@MainActivity, RateTriple(6.0, 4.0, 3.0), force = true)
                runOnUiThread { refreshLog(); toast("테스트 신호를 전송했습니다. S26에서 '지금 실행/수신 확인'을 눌러도 됩니다.") }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshLog()
    }

    private fun load() {
        if (Prefs.role(this) == Prefs.ROLE_RECEIVER) binding.receiverRadio.isChecked = true
        else binding.collectorRadio.isChecked = true
        binding.topicEdit.setText(Prefs.topic(this))
        binding.enabledSwitch.isChecked = Prefs.enabled(this)
        refreshLog()
    }

    private fun save() {
        Prefs.setRole(this, if (binding.receiverRadio.isChecked) Prefs.ROLE_RECEIVER else Prefs.ROLE_COLLECTOR)
        Prefs.setTopic(this, binding.topicEdit.text.toString())
        Prefs.setEnabled(this, binding.enabledSwitch.isChecked)
    }

    private fun refreshLog() {
        binding.logText.text = LogStore.latest(this)
    }

    private fun requestNotificationIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
