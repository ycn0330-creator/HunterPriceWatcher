package com.openai.hunterwatcher

import android.content.Context
import java.security.SecureRandom
import java.time.ZoneId
import java.time.ZonedDateTime

object Prefs {
    const val ROLE_COLLECTOR = "collector"
    const val ROLE_RECEIVER = "receiver"
    const val THRESHOLD = 5.8
    const val QUIET_START_HOUR = 23
    const val QUIET_END_HOUR = 9
    val SEOUL_ZONE: ZoneId = ZoneId.of("Asia/Seoul")

    private const val NAME = "hunter_watcher"
    private const val KEY_ROLE = "role"
    private const val KEY_TOPIC = "topic"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_LAST_NTFY_ID = "last_ntfy_id"

    private fun sp(context: Context) = context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun role(context: Context): String = sp(context).getString(KEY_ROLE, ROLE_COLLECTOR) ?: ROLE_COLLECTOR
    fun setRole(context: Context, value: String) = sp(context).edit().putString(KEY_ROLE, value).apply()

    fun enabled(context: Context): Boolean = sp(context).getBoolean(KEY_ENABLED, true)
    fun setEnabled(context: Context, value: Boolean) = sp(context).edit().putBoolean(KEY_ENABLED, value).apply()

    fun topic(context: Context): String {
        val current = sp(context).getString(KEY_TOPIC, null)
        if (!current.isNullOrBlank()) return current
        val created = newTopicCode()
        setTopic(context, created)
        return created
    }

    fun setTopic(context: Context, value: String) {
        val cleaned = value.trim().replace(Regex("[^A-Za-z0-9_-]"), "")
        if (cleaned.length >= 16) sp(context).edit().putString(KEY_TOPIC, cleaned).apply()
    }

    fun newTopicCode(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return "hunter-" + bytes.joinToString("") { "%02x".format(it) }
    }

    fun lastNtfyId(context: Context): String? = sp(context).getString(KEY_LAST_NTFY_ID, null)
    fun setLastNtfyId(context: Context, id: String) = sp(context).edit().putString(KEY_LAST_NTFY_ID, id).apply()

    fun isQuietTime(now: ZonedDateTime = ZonedDateTime.now(SEOUL_ZONE)): Boolean {
        val h = now.hour
        return h >= QUIET_START_HOUR || h < QUIET_END_HOUR
    }
}
