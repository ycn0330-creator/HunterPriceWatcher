package com.openai.hunterwatcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Scheduler.scheduleNext(context)
        LogStore.add(context, "부팅/업데이트 후 스케줄 재등록")
    }
}
