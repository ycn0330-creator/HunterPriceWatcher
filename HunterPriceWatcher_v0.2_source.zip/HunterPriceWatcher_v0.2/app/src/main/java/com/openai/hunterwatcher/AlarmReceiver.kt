package com.openai.hunterwatcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (!Prefs.enabled(context)) return
        Scheduler.scheduleNext(context)

        if (Prefs.role(context) == Prefs.ROLE_COLLECTOR) {
            if (!HunterAccessibilityService.requestAutomation("정각")) {
                LogStore.add(context, "접근성 서비스가 실행 중이 아니어서 자동 확인 실패")
            }
        } else {
            val pending = goAsync()
            CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                try {
                    RelayClient.pollAndNotify(context)
                } finally {
                    pending.finish()
                }
            }
        }
    }
}
