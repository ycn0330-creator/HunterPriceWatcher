package com.openai.hunterwatcher

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.ZonedDateTime

object Scheduler {
    const val ACTION_TICK = "com.openai.hunterwatcher.ACTION_TICK"

    fun scheduleNext(context: Context) {
        if (!Prefs.enabled(context)) return
        val role = Prefs.role(context)
        val second = if (role == Prefs.ROLE_COLLECTOR) 5 else 45
        val now = ZonedDateTime.now(Prefs.SEOUL_ZONE)
        var next = now.withMinute(0).withSecond(second).withNano(0)
        if (!next.isAfter(now)) next = next.plusHours(1)

        val intent = Intent(context, AlarmReceiver::class.java).setAction(ACTION_TICK)
        val pi = PendingIntent.getBroadcast(
            context,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val am = context.getSystemService(AlarmManager::class.java)
        val whenMillis = next.toInstant().toEpochMilli()
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pi)
            LogStore.add(context, "정확한 알람 권한 없음: 근사 스케줄 사용")
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pi)
        }
    }
}
