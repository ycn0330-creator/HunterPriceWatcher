package com.openai.hunterwatcher

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.PowerManager
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import com.google.android.gms.tasks.await
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

class HunterAccessibilityService : AccessibilityService() {
    companion object {
        private const val GAME_PACKAGE = "com.superpixel.undyinghero"

        // Lenovo Legion Y700 4th Gen user screenshots (landscape) reference size.
        // All fallback touch/crop coordinates below are based on 1536 x 962.
        private const val REF_W = 1536f
        private const val REF_H = 962f

        private var instance: HunterAccessibilityService? = null

        fun requestAutomation(trigger: String): Boolean {
            val s = instance ?: return false
            s.startAutomation(trigger)
            return true
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val running = AtomicBoolean(false)
    private val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Scheduler.scheduleNext(this)
        LogStore.add(this, "접근성 서비스 연결됨 · Y700 1536x962 프로필")
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        recognizer.close()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    private fun startAutomation(trigger: String) {
        if (!Prefs.enabled(this) || Prefs.role(this) != Prefs.ROLE_COLLECTOR) return
        if (!running.compareAndSet(false, true)) return
        scope.launch {
            val pm = getSystemService(PowerManager::class.java)
            @Suppress("DEPRECATION")
            val wl = pm.newWakeLock(
                PowerManager.SCREEN_DIM_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "HunterWatcher:scan"
            )
            wl.acquire(90_000)
            try {
                LogStore.add(this@HunterAccessibilityService, "$trigger 시세 확인 시작")
                ensureGameForeground()
                runFlow()
            } catch (t: Throwable) {
                LogStore.add(this@HunterAccessibilityService, "자동 확인 오류: ${t.message}")
            } finally {
                if (wl.isHeld) wl.release()
                running.set(false)
            }
        }
    }

    private suspend fun ensureGameForeground() {
        if (rootInActiveWindow?.packageName?.toString() == GAME_PACKAGE) return
        val launch = packageManager.getLaunchIntentForPackage(GAME_PACKAGE)
            ?.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            ?: error("불사용사 키우기 앱을 찾을 수 없음")
        startActivity(launch)
        repeat(15) {
            delay(1_000)
            if (rootInActiveWindow?.packageName?.toString() == GAME_PACKAGE) return
        }
        error("게임을 전면으로 가져오지 못함")
    }

    private fun assertGameForeground() {
        if (rootInActiveWindow?.packageName?.toString() != GAME_PACKAGE) {
            error("게임이 전면 화면이 아니어서 터치를 중단함")
        }
    }

    private suspend fun runFlow() {
        // 1) Current state check. If this is the game's own power-save screen, unlock it.
        var shot = captureBitmap() ?: error("스크린샷 실패")
        var text = recognize(shot)
        if (isPowerSaveScreen(text)) {
            assertGameForeground()
            // Y700 screenshot: slider spans roughly x=495..1030, y=755..850.
            swipeRef(535f, 800f, 1005f, 800f, 700)
            delay(2_000)
            shot.recycle()
            shot = captureBitmap() ?: error("절전 해제 후 스크린샷 실패")
            text = recognize(shot)
            LogStore.add(this, "게임 절전 모드 해제")
        }

        // 2) Open Hunter Quest safely. If Hunter Quest popup is already open, do not touch the background.
        if (!isHunterWindow(text)) {
            val hunterCenter = findTextCenter(shot, "헌터 퀘스트")
            if (hunterCenter != null && isMenuScreen(text)) {
                assertGameForeground()
                tapPx(hunterCenter.first, hunterCenter.second)
            } else {
                // Menu may be closed. Open it and require menu markers before proceeding.
                assertGameForeground()
                tapRef(1493f, 48f)
                delay(900)
                shot.recycle()
                shot = captureBitmap() ?: error("메뉴 확인 스크린샷 실패")
                text = recognize(shot)
                if (!isMenuScreen(text)) error("게임 메뉴를 확인하지 못해 터치를 중단함")
                val detected = findTextCenter(shot, "헌터 퀘스트")
                if (detected != null) tapPx(detected.first, detected.second)
                else tapRef(1277f, 169f) // Y700 fallback only after menu verification.
            }
            delay(1_300)
            shot.recycle()
            shot = captureBitmap() ?: error("헌터 퀘스트 진입 확인 실패")
            text = recognize(shot)
            if (!isHunterWindow(text)) error("헌터 퀘스트 창을 확인하지 못함")
        }

        // 3) Exchange tab. Prefer OCR position; use Y700 fallback only inside verified Hunter window.
        val exchangeCenter = findTextCenter(shot, "환전소")
        assertGameForeground()
        if (exchangeCenter != null) tapPx(exchangeCenter.first, exchangeCenter.second)
        else tapRef(374f, 266f)
        delay(1_500)
        shot.recycle()

        // 4) Read rates twice. Third read is used only if the first two disagree.
        val first = readRates() ?: error("1차 시세 인식 실패")
        delay(850)
        val second = readRates() ?: error("2차 시세 인식 실패")
        val rates = if (first.closeTo(second)) second else {
            delay(850)
            val third = readRates() ?: error("재시도 시세 인식 실패")
            if (!second.closeTo(third)) error("시세 인식값 불일치: $first / $second / $third")
            third
        }

        val msg = "금 x${rates.gold.oneDecimal()} / 은 x${rates.silver.oneDecimal()} / 구리 x${rates.copper.oneDecimal()}"
        LogStore.add(this, "시세 확인 완료: $msg")

        // No selling action exists in this app. Only x5.8+ notification is sent.
        if (rates.max() >= Prefs.THRESHOLD) {
            if (Prefs.isQuietTime()) {
                LogStore.add(this, "x5.8 이상 감지했지만 23:00~09:00라 알림 생략")
            } else {
                RelayClient.publishAlert(this, rates)
            }
        }

        // 5) Close Hunter Quest window. X is far away from all sell buttons.
        assertGameForeground()
        tapRef(1335f, 201f)
        delay(900)

        // 6) Return to the game's power-save mode. Never blind-tap unless menu text is verified.
        var after = captureBitmap() ?: error("복귀 화면 캡처 실패")
        var afterText = recognize(after)
        if (!isMenuScreen(afterText)) {
            tapRef(1493f, 48f)
            delay(800)
            after.recycle()
            after = captureBitmap() ?: error("복귀 메뉴 확인 실패")
            afterText = recognize(after)
        }

        if (isMenuScreen(afterText)) {
            val sleepCenter = findTextCenter(after, "절전 모드")
            if (sleepCenter != null) tapPx(sleepCenter.first, sleepCenter.second)
            else tapRef(1277f, 357f)
            LogStore.add(this, "게임 절전 모드 복귀 요청")
        } else {
            LogStore.add(this, "메뉴를 확인하지 못해 절전 모드 복귀 터치를 생략")
        }
        after.recycle()
    }

    private fun isPowerSaveScreen(text: String): Boolean {
        val t = normalized(text)
        return t.contains("밀어서잠금해제") || t.contains("잠금해제") ||
            (t.contains("획득보상") && t.contains("전투시간"))
    }

    private fun isHunterWindow(text: String): Boolean {
        val t = normalized(text)
        return t.contains("헌터퀘스트") && t.contains("환전소") && t.contains("엠블럼")
    }

    private fun isMenuScreen(text: String): Boolean {
        val t = normalized(text)
        return t.contains("헌터퀘스트") && (t.contains("절전모드") || t.contains("게임종료"))
    }

    private fun normalized(s: String): String = s.replace(Regex("\\s+"), "")

    private suspend fun readRates(): RateTriple? {
        val bitmap = captureBitmap() ?: return null
        try {
            // Primary: OCR all text elements in the Y700 rate row, sort left-to-right.
            readRatesFromElements(bitmap)?.let { return it }

            // Fallback: three Y700-specific crops from the supplied exchange screenshot.
            val gold = readRateCrop(bitmap, Rect(245, 582, 405, 650)) ?: return null
            val silver = readRateCrop(bitmap, Rect(462, 582, 620, 650)) ?: return null
            val copper = readRateCrop(bitmap, Rect(675, 582, 835, 650)) ?: return null
            return RateTriple(gold, silver, copper)
        } finally {
            bitmap.recycle()
        }
    }

    private suspend fun readRatesFromElements(bitmap: Bitmap): RateTriple? {
        val result = recognizeResult(bitmap)
        val values = mutableListOf<Pair<Float, Double>>()
        for (block in result.textBlocks) {
            for (line in block.lines) {
                for (element in line.elements) {
                    val box = element.boundingBox ?: continue
                    val cxRef = box.centerX() * REF_W / bitmap.width
                    val cyRef = box.centerY() * REF_H / bitmap.height
                    // Rate badges on supplied Y700 screen: y≈618, x≈330/545/760.
                    if (cxRef !in 210f..880f || cyRef !in 560f..665f) continue
                    val rate = parseRate(element.text) ?: continue
                    values += cxRef to rate
                }
                val lineBox = line.boundingBox
                if (lineBox != null) {
                    val cxRef = lineBox.centerX() * REF_W / bitmap.width
                    val cyRef = lineBox.centerY() * REF_H / bitmap.height
                    if (cxRef in 210f..880f && cyRef in 560f..665f) {
                        parseRate(line.text)?.let { values += cxRef to it }
                    }
                }
            }
        }

        // De-duplicate line+element detections and keep 3 left-to-right rates.
        val sorted = values.sortedBy { it.first }
        val dedup = mutableListOf<Pair<Float, Double>>()
        for (v in sorted) {
            if (dedup.none { kotlin.math.abs(it.first - v.first) < 45f }) dedup += v
        }
        if (dedup.size < 3) return null
        val three = dedup.take(3)
        return RateTriple(three[0].second, three[1].second, three[2].second)
    }

    private suspend fun readRateCrop(bitmap: Bitmap, ref: Rect): Double? {
        val left = (ref.left * bitmap.width / REF_W).toInt().coerceIn(0, bitmap.width - 2)
        val top = (ref.top * bitmap.height / REF_H).toInt().coerceIn(0, bitmap.height - 2)
        val right = (ref.right * bitmap.width / REF_W).toInt().coerceIn(left + 1, bitmap.width)
        val bottom = (ref.bottom * bitmap.height / REF_H).toInt().coerceIn(top + 1, bitmap.height)
        val crop = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
        val scaled = Bitmap.createScaledBitmap(crop, crop.width * 4, crop.height * 4, true)
        crop.recycle()
        return try {
            val result = recognizeResult(scaled)
            val candidates = buildList {
                for (block in result.textBlocks) {
                    for (line in block.lines) {
                        parseRate(line.text)?.let { add(it) }
                        for (element in line.elements) parseRate(element.text)?.let { add(it) }
                    }
                }
            }
            candidates.firstOrNull()
        } finally {
            scaled.recycle()
        }
    }

    private fun parseRate(raw: String): Double? {
        var s = raw.lowercase()
            .replace('×', 'x')
            .replace(',', '.')
            .replace(" ", "")
            .replace('s', '5')
            .replace('b', '6')
            .replace('i', '1')
            .replace('l', '1')
            .replace('o', '0')
        s = s.replace(Regex("[^x0-9.]"), "")

        // Normal form: x5.8 / 5.8
        Regex("""^x?([1-6])\\.([0-9])$""").matchEntire(s)?.let {
            return "${it.groupValues[1]}.${it.groupValues[2]}".toDouble()
        }
        // OCR sometimes drops the decimal point: x58 -> 5.8, x20 -> 2.0.
        Regex("""^x?([1-6])([0-9])$""").matchEntire(s)?.let {
            return "${it.groupValues[1]}.${it.groupValues[2]}".toDouble()
        }
        // Rare exact integer (e.g. 6) is accepted as 6.0.
        Regex("""^x?([1-6])$""").matchEntire(s)?.let {
            return it.groupValues[1].toDouble()
        }
        return null
    }

    private suspend fun findTextCenter(bitmap: Bitmap, wanted: String): Pair<Float, Float>? {
        val target = normalized(wanted)
        val result = recognizeResult(bitmap)
        for (block in result.textBlocks) {
            for (line in block.lines) {
                if (normalized(line.text).contains(target)) {
                    val b = line.boundingBox ?: continue
                    return b.exactCenterX() to b.exactCenterY()
                }
            }
        }
        return null
    }

    private suspend fun recognize(bitmap: Bitmap): String = recognizeResult(bitmap).text

    private suspend fun recognizeResult(bitmap: Bitmap): Text {
        return recognizer.process(InputImage.fromBitmap(bitmap, 0)).await()
    }

    private suspend fun captureBitmap(): Bitmap? = suspendCancellableCoroutine { cont ->
        if (Build.VERSION.SDK_INT < 30) {
            cont.resume(null)
            return@suspendCancellableCoroutine
        }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val hb = screenshot.hardwareBuffer
                val wrapped = Bitmap.wrapHardwareBuffer(hb, screenshot.colorSpace)
                val copy = wrapped?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                cont.resume(copy)
            }

            override fun onFailure(errorCode: Int) {
                LogStore.add(this@HunterAccessibilityService, "스크린샷 실패 코드 $errorCode")
                cont.resume(null)
            }
        })
    }

    private fun tapPx(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 80))
            .build()
        dispatchGesture(g, null, null)
    }

    private fun tapRef(x: Float, y: Float) {
        val metrics = resources.displayMetrics
        val px = x * metrics.widthPixels / REF_W
        val py = y * metrics.heightPixels / REF_H
        tapPx(px, py)
    }

    private fun swipeRef(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long) {
        val metrics = resources.displayMetrics
        val sx = metrics.widthPixels / REF_W
        val sy = metrics.heightPixels / REF_H
        val p = Path().apply {
            moveTo(x1 * sx, y1 * sy)
            lineTo(x2 * sx, y2 * sy)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, duration))
            .build()
        dispatchGesture(g, null, null)
    }

    private fun Double.oneDecimal() = String.format(java.util.Locale.US, "%.1f", this)
}
