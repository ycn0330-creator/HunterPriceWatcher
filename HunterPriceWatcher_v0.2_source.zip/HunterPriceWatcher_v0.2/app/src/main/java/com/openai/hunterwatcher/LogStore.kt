package com.openai.hunterwatcher

import android.content.Context
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

object LogStore {
    private const val PREF = "hunter_log"
    private const val KEY = "lines"
    private val fmt = DateTimeFormatter.ofPattern("MM-dd HH:mm:ss")

    fun add(context: Context, message: String) {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val now = ZonedDateTime.now(Prefs.SEOUL_ZONE).format(fmt)
        val line = "$now  $message"
        val old = sp.getString(KEY, "").orEmpty().lines().filter { it.isNotBlank() }
        val lines = (listOf(line) + old).take(200)
        sp.edit().putString(KEY, lines.joinToString("\n")).apply()
    }

    fun latest(context: Context): String =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "기록 없음").orEmpty()
}
